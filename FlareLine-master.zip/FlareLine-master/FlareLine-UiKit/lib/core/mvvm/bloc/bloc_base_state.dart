import 'package:equatable/equatable.dart';

abstract class BlocBaseState extends Equatable{

}