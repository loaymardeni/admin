import 'package:equatable/equatable.dart';

abstract class BaseState extends Equatable{

}