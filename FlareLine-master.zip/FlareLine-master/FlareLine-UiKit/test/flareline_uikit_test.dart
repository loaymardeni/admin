import 'package:flutter_test/flutter_test.dart';

import 'package:flareline_uikit/flareline_uikit.dart';

void main() {
  test('adds one to input values', () {

  });
}
